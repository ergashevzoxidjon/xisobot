import os
import re
from datetime import datetime
import uuid
from decimal import Decimal

from flask import (
    Blueprint, render_template, request, redirect, url_for, flash,
    current_app, send_from_directory, jsonify,
)
from flask_login import login_required, current_user
from sqlalchemy import func, or_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload, selectinload
from werkzeug.utils import secure_filename

from extensions import db
from models import (
    Order, OrderItem, Client, Payment, OrderType, OrderFile, CompanySettings,
    ClientPipelineCard, User, log_action, can_transition,
    ORDER_STATUSES, ALLOWED_TRANSITIONS, STATUS_CANCELLED, STATUS_PRODUCTION,
    STATUS_READY, ZERO, ORDER_PAYMENT_METHODS,
    CashHandover, HANDOVER_PENDING, CASH_PAYMENT_METHOD, CARD_PAYMENT_METHOD,
    HANDOVER_CHANNEL_CASH, HANDOVER_CHANNEL_CARD,
    StockMove, STOCK_IN, STOCK_OUT,
)
from notifications import notify_new_order, notify_payment
from permissions import permission_required, has_perm
from queries import eager_orders
from utils import (
    ValidationError, parse_money, parse_int, parse_date, parse_text, parse_choice,
    to_money, today_local, now_local, money_str, qty_str,
)

orders_bp = Blueprint("orders", __name__, url_prefix="/buyurtmalar")

# Sahifa bir necha soniya "qotib qolganda" menejer tugmani qayta bosib,
# bitta to'lovni ikki marta yuborib yuborishi mumkin edi (2026-09-03,
# foydalanuvchi xabari). Shu buyurtmaga oxirgi to'lov shu vaqt ichida
# yozilgan bo'lsa — keyingisi bloklanadi (frontendda tugma ham darhol
# o'chiriladi, lekin bu — asosiy, server tomonidagi himoya).
PAYMENT_COOLDOWN_SECONDS = 60


def next_order_number():
    """Yil + ketma-ket raqam. Mavjud eng katta raqamdan davom etadi,
    shuning uchun buyurtma o'chirilsa ham takrorlanmaydi."""
    year = today_local().year
    prefix = f"B-{year}-"
    last = (
        Order.query.filter(Order.order_number.like(f"{prefix}%"))
        .order_by(Order.order_number.desc())
        .first()
    )
    if last:
        try:
            seq = int(last.order_number.rsplit("-", 1)[1]) + 1
        except (ValueError, IndexError):
            seq = Order.query.count() + 1
    else:
        seq = 1
    return f"{prefix}{seq:04d}"


MAX_ITEMS = 50


def _at(values, index, default=""):
    return values[index] if index < len(values) else default


def _items_from_form(form):
    """Formadagi mahsulot qatorlarini o'qiydi va tekshiradi.

    Buyurtma turi bo'sh qolgan qatorlar e'tiborsiz qoldiriladi — foydalanuvchi
    ortiqcha qator qo'shib, uni to'ldirmasdan yuborishi mumkin.
    """
    types = form.getlist("item_type")
    descriptions = form.getlist("item_description")
    quantities = form.getlist("item_quantity")
    prices = form.getlist("item_unit_price")

    if len(types) > MAX_ITEMS:
        raise ValidationError(f"Bitta buyurtmada {MAX_ITEMS} tadan ko'p qator bo'lmasin.")

    items = []
    for index, raw_type in enumerate(types):
        name = (raw_type or "").strip()
        if not name:
            continue

        row = index + 1
        quantity = parse_int(
            _at(quantities, index), f"{row}-qator, miqdor",
            min_value=1, max_value=10_000_000,
        )
        unit_price = parse_money(
            _at(prices, index), f"{row}-qator, birlik narxi", min_value=ZERO,
        )
        items.append({
            "order_type": parse_text(
                name, f"{row}-qator, buyurtma turi", required=True, max_length=100
            ),
            "description": parse_text(
                _at(descriptions, index), f"{row}-qator, texnik parametr",
                required=True, max_length=500,
            ),
            "quantity": quantity,
            "unit_price": unit_price,
            "total_price": to_money(Decimal(quantity) * unit_price),
            "position": len(items),
        })

    if not items:
        raise ValidationError("Kamida bitta mahsulot qatorini to'ldiring.")
    return items


def _client_from_form(form):
    """Formadagi mijozni topadi, kerak bo'lsa yangisini yaratadi.

    Ro'yxatdan tanlansa `client_id` keladi. Foydalanuvchi yangi nom yozgan
    bo'lsa — avval shu nomli mijoz bazada bor-yo'qligi tekshiriladi
    (katta-kichik harf farqsiz), topilmasa yangi mijoz ochiladi.

    (mijoz, yangi_yaratildimi) juftligini qaytaradi.
    """
    raw_id = (form.get("client_id") or "").strip()
    if raw_id:
        client = db.session.get(Client, parse_int(raw_id, "Mijoz", min_value=1))
        if client and not client.is_deleted:
            return client, False

    name = parse_text(form.get("client_name"), "Mijoz", required=True, max_length=150)

    existing = (
        Client.query.filter(Client.name.ilike(name), Client.is_deleted.is_(False))
        .first()
    )
    if existing:
        return existing, False

    if not has_perm("clients.create"):
        raise ValidationError(
            f"Mijoz: '{name}' bazada topilmadi, yangi mijoz qo'shish huquqingiz esa yo'q."
        )

    client = Client(
        name=name,
        phone=parse_text(form.get("client_phone"), "Telefon", required=False, max_length=50),
        company=parse_text(form.get("client_company"), "Korxona", required=False, max_length=150),
        created_by=current_user.id,
    )
    db.session.add(client)
    db.session.flush()
    return client, True


def _order_common_fields(form):
    return {
        "description": parse_text(
            form.get("description"), "Umumiy izoh", required=False, max_length=2000
        ),
        "deadline": parse_date(form.get("deadline"), "Muddat", required=False),
    }


def _own_orders_only():
    """Bir nechta menejer bo'lishi mumkin — har biri faqat o'zi yaratgan
    buyurtmalarni ko'rishi/boshqarishi kerak (2026-09-03, foydalanuvchi
    qarori). Admin va xarajatchi (ish boshqaruvchi) — hammasini ko'radi,
    chunki ularga umumiy nazorat kerak."""
    return current_user.role == "menejer"


def _guard_order_owner(o):
    """Menejer boshqa menejerning buyurtmasiga kira olmaydi (to'g'ridan-to'g'ri
    URL orqali ham) — ro'yxatdagi filtr bilan bir xil qoidani mustahkamlaydi."""
    if _own_orders_only() and o.created_by != current_user.id:
        flash("Bu buyurtma sizga tegishli emas.", "danger")
        return redirect(url_for("orders.list_orders"))
    return None


@orders_bp.route("/")
@login_required
@permission_required("orders.view")
def list_orders():
    status = request.args.get("status", "")
    q = (request.args.get("q") or "").strip()
    page = request.args.get("page", 1, type=int)
    # Bir nechta menejer bo'lganda admin/xarajatchi hammasini ko'rgani
    # uchun, kerakli menejerni tezroq topish uchun filtr (2026-09-05,
    # foydalanuvchi qarori). Menejerning o'ziga bu filtr kerak emas — u
    # baribir faqat o'zinikini ko'radi.
    show_manager_filter = not _own_orders_only()
    manager_id = request.args.get("manager_id", type=int) if show_manager_filter else None

    query = Order.query.join(Client).filter(Order.is_deleted.is_(False))
    if _own_orders_only():
        query = query.filter(Order.created_by == current_user.id)
    elif manager_id:
        query = query.filter(Order.created_by == manager_id)

    # Oylar bo'yicha bo'limlar: har oy alohida tab. Standart — joriy oy;
    # qidiruv berilganda esa hamma oylar bo'yicha qidiriladi.
    month_rows = (
        query.with_entities(
            func.extract("year", Order.created_at),
            func.extract("month", Order.created_at),
            func.count(Order.id),
        )
        .group_by(func.extract("year", Order.created_at), func.extract("month", Order.created_at))
        .all()
    )
    month_tabs = sorted(
        ((int(y), int(m), c) for y, m, c in month_rows if y and m), reverse=True
    )
    month = request.args.get("month")
    if month is None:
        month = "" if q else now_local().strftime("%Y-%m")
        # Joriy oyda hali buyurtma bo'lmasa — oxirgi buyurtmali oyni ko'rsatamiz
        if month and month_tabs and not any(f"{y:04d}-{m:02d}" == month for y, m, _ in month_tabs):
            month = f"{month_tabs[0][0]:04d}-{month_tabs[0][1]:02d}"
    month_start = None
    if re.fullmatch(r"\d{4}-\d{2}", month or ""):
        y, m = int(month[:4]), int(month[5:])
        if 1 <= m <= 12:
            month_start = datetime(y, m, 1)
            nxt = datetime(y + (m == 12), m % 12 + 1, 1)
            query = query.filter(Order.created_at >= month_start, Order.created_at < nxt)
    if month_start is None:
        month = ""

    if status and status in ORDER_STATUSES:
        query = query.filter(Order.status == status)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(
            Order.order_number.ilike(like),
            Order.order_type.ilike(like),
            Client.name.ilike(like),
        ))

    # eager yuklash: 51 ta so'rov o'rniga 3 ta
    query = eager_orders(query.order_by(Order.created_at.desc()))
    pagination = query.paginate(
        page=page, per_page=current_app.config["PER_PAGE"], error_out=False
    )

    managers = []
    if show_manager_filter:
        managers = (
            User.query.filter_by(role="menejer")
            .order_by(User.username).all()
        )

    return render_template(
        "orders/list.html",
        orders=pagination.items,
        pagination=pagination,
        statuses=ORDER_STATUSES,
        status=status,
        q=q,
        managers=managers,
        manager_id=manager_id,
        month=month,
        month_tabs=month_tabs,
    )


@orders_bp.route("/qidiruv")
@login_required
@permission_required("orders.view")
def search_orders():
    """Xarajat formasidagi buyurtma qidiruvi uchun — JSON qaytaradi.

    Raqam, mijoz nomi yoki mahsulot turi bo'yicha qidiradi.
    """
    q = (request.args.get("q") or "").strip()

    query = (
        Order.query.options(
            joinedload(Order.client), selectinload(Order.items), joinedload(Order.creator)
        )
        .join(Client)
        .filter(Order.is_deleted.is_(False))
    )
    if q:
        like = f"%{q}%"
        query = query.outerjoin(OrderItem, OrderItem.order_id == Order.id).filter(or_(
            Order.order_number.ilike(like),
            Client.name.ilike(like),
            OrderItem.order_type.ilike(like),
        )).distinct()

    rows = query.order_by(Order.created_at.desc()).limit(10).all()
    return jsonify([
        {
            "id": o.id,
            "number": o.order_number,
            "client": o.client.name if o.client else "",
            "summary": o.items_summary,
            "total": money_str(o.total_price),
            "creator": o.creator.display_name if o.creator else "",
        }
        for o in rows
    ])


@orders_bp.route("/yangi", methods=["GET", "POST"])
@login_required
@permission_required("orders.create")
def new_order():
    order_types = OrderType.query.filter_by(is_active=True).order_by(OrderType.name).all()

    # "Nusxalash" — mavjud buyurtma asosida formani to'ldirish
    prefill = None
    copy_from = request.args.get("copy", type=int)
    if request.method == "GET" and copy_from:
        src = db.session.get(Order, copy_from)
        if src and not (_own_orders_only() and src.created_by != current_user.id):
            prefill = src

    # Mijoz oldindan tanlangan holda kelish (masalan, Manager xisobotidagi
    # "Mijozlar bilan ishlash" pipeline kartasi "Muvaffaqiyatli" bosqichiga
    # o'tkazilgach, "Buyurtma yaratish" havolasi orqali — 2026-08-29,
    # to'rtinchi so'rov).
    prefill_client_id = ""
    prefill_client_name = ""
    if request.method == "GET" and not prefill:
        pid = request.args.get("client_id", type=int)
        if pid:
            pc = db.session.get(Client, pid)
            if pc:
                prefill_client_id = pc.id
                prefill_client_name = pc.name
        elif request.args.get("client_name"):
            # Nomi bor, lekin hali bazadagi mijozga bog'lanmagan (masalan,
            # menejer jurnalida qo'lda kiritilgan mijoz) — matn to'ldiriladi,
            # forma o'zi mavjud mijozni topadi yoki yangisini yaratadi.
            prefill_client_name = request.args.get("client_name")

    # Pipeline kartasi shu buyurtma orqali "yopiladi" — buyurtma saqlangach
    # shu kartaga order_id yoziladi (2026-08-29, to'rtinchi so'rov).
    pipeline_card_id = request.args.get("pipeline_card_id", type=int) if request.method == "GET" else None

    def back_to_form():
        return render_template(
            "orders/form.html", order_types=order_types,
            order=None, prefill=None, form=request.form,
        )

    if request.method == "POST":
        try:
            # Avval qatorlarni tekshiramiz — xato bo'lsa bekorga
            # yangi mijoz yaratilib qolmasligi uchun.
            items = _items_from_form(request.form)
            common = _order_common_fields(request.form)
            client, client_created = _client_from_form(request.form)
        except ValidationError as e:
            db.session.rollback()
            flash(str(e), "danger")
            return back_to_form()

        if client_created:
            log_action(current_user, "create", "client", client.id,
                       f"{client.name} (buyurtma orqali)")
            db.session.commit()

        # Ikki xodim bir vaqtda buyurtma yaratsa raqam to'qnashishi mumkin —
        # bunda qayta urinamiz (500 xato o'rniga).
        o = None
        for attempt in range(5):
            o = Order(
                order_number=next_order_number(),
                client_id=client.id,
                created_by=current_user.id,
                **common,
            )
            for data in items:
                o.items.append(OrderItem(**data))
            o.recalc_from_items()
            db.session.add(o)
            try:
                db.session.flush()
                break
            except IntegrityError:
                db.session.rollback()
                o = None
                if attempt == 4:
                    flash("Buyurtma raqamini yaratib bo'lmadi. Qayta urinib ko'ring.", "danger")
                    return back_to_form()

        log_action(current_user, "create", "order", o.id,
                   f"{o.order_number} yaratildi ({len(items)} qator)")

        # Pipeline kartasidan kelgan bo'lsa — shu karta shu buyurtma bilan
        # "yopiladi" (2026-08-29, to'rtinchi so'rov).
        posted_card_id = request.form.get("pipeline_card_id", type=int)
        if posted_card_id:
            card = db.session.get(ClientPipelineCard, posted_card_id)
            if card:
                card.order_id = o.id

        db.session.commit()
        notify_new_order(o)
        if client_created:
            flash(f"Yangi mijoz qo'shildi: {client.name}", "info")
        flash(f"Buyurtma {o.order_number} yaratildi.", "success")
        return redirect(url_for("orders.order_detail", order_id=o.id))

    return render_template(
        "orders/form.html", order_types=order_types,
        order=None, prefill=prefill, form=None,
        prefill_client_id=prefill_client_id, prefill_client_name=prefill_client_name,
        pipeline_card_id=pipeline_card_id,
    )


@orders_bp.route("/<int:order_id>/tahrirlash", methods=["GET", "POST"])
@login_required
@permission_required("orders.edit")
def edit_order(order_id):
    o = Order.query.get_or_404(order_id)
    guard = _guard_order_owner(o)
    if guard:
        return guard
    order_types = OrderType.query.filter_by(is_active=True).order_by(OrderType.name).all()

    def back_to_form(keep_form=True):
        return render_template(
            "orders/form.html", order_types=order_types,
            order=o, prefill=None, form=request.form if keep_form else None,
        )

    if request.method == "POST":
        try:
            items = _items_from_form(request.form)
            common = _order_common_fields(request.form)
            client, client_created = _client_from_form(request.form)
        except ValidationError as e:
            db.session.rollback()
            flash(str(e), "danger")
            return back_to_form()

        # boshqa xodim shu orada o'zgartirmaganini tekshiramiz
        form_version = parse_int(
            request.form.get("version"), "Versiya",
            required=False, min_value=0, default=0,
        )
        if form_version and form_version != o.version:
            db.session.rollback()
            flash(
                "Bu buyurtmani shu orada boshqa xodim o'zgartirdi. "
                "Sahifa yangilandi — o'zgarishlaringizni qayta kiriting.", "warning",
            )
            return back_to_form(keep_form=False)

        # yangi summa to'langan puldan kam bo'lib qolmasligini tekshiramiz
        new_total = sum((data["total_price"] for data in items), ZERO)
        if new_total < o.paid_amount_calc:
            db.session.rollback()
            flash(
                "Yangi summa allaqachon to'langan puldan kam bo'lishi mumkin emas "
                f"(to'langan: {o.paid_amount_calc}).", "danger",
            )
            return back_to_form()

        if client_created:
            log_action(current_user, "create", "client", client.id,
                       f"{client.name} (buyurtma orqali)")

        o.client_id = client.id
        for key, value in common.items():
            setattr(o, key, value)

        # eski qatorlarni yangilari bilan almashtiramiz
        o.items.clear()
        for data in items:
            o.items.append(OrderItem(**data))
        o.recalc_from_items()

        o.version = (o.version or 1) + 1
        log_action(current_user, "update", "order", o.id,
                   f"{o.order_number} tahrirlandi ({len(items)} qator)")
        db.session.commit()
        flash("Buyurtma yangilandi.", "success")
        return redirect(url_for("orders.order_detail", order_id=o.id))

    return render_template(
        "orders/form.html", order_types=order_types,
        order=o, prefill=None, form=None,
    )


@orders_bp.route("/<int:order_id>")
@login_required
@permission_required("orders.view")
def order_detail(order_id):
    o = Order.query.options(joinedload(Order.client)).get_or_404(order_id)
    guard = _guard_order_owner(o)
    if guard:
        return guard
    payments = sorted(o.payments, key=lambda p: (p.paid_on, p.id), reverse=True)
    # faqat shu holatdan o'tish mumkin bo'lganlarini ko'rsatamiz
    possible = [s for s in ALLOWED_TRANSITIONS.get(o.status, []) if s != o.status]
    if has_perm("orders.manage"):
        allowed = [o.status] + possible
    elif has_perm("orders.status") and o.status == STATUS_PRODUCTION and STATUS_READY in possible:
        # Ish boshqaruvchi — faqat "ishlab chiqarishda" -> "yetkazish uchun
        # tayyor" o'tishini ko'radi (2026-09-05, foydalanuvchi qarori).
        allowed = [o.status, STATUS_READY]
    else:
        allowed = [o.status]
    return render_template(
        "orders/detail.html", order=o, payments=payments, statuses=allowed,
        order_payment_methods=ORDER_PAYMENT_METHODS,
        active_xarajatchi=_active_xarajatchi() if has_perm("orders.manage") else [],
        active_boss=_active_boss() if has_perm("orders.manage") else [],
    )


@orders_bp.route("/<int:order_id>/hisob-faktura")
@login_required
@permission_required("orders.view")
def invoice(order_id):
    o = Order.query.options(joinedload(Order.client)).get_or_404(order_id)
    guard = _guard_order_owner(o)
    if guard:
        return guard
    return render_template(
        "orders/invoice.html", order=o, today=today_local(),
        company=CompanySettings.get(),
    )


@orders_bp.route("/<int:order_id>/holat", methods=["POST"])
@login_required
@permission_required("orders.view")
def update_status(order_id):
    o = Order.query.get_or_404(order_id)
    guard = _guard_order_owner(o)
    if guard:
        return guard

    # To'liq huquq — admin/menejer (orders.manage). Ish boshqaruvchi
    # (orders.status) esa FAQAT "ishlab chiqarishda" -> "yetkazish uchun
    # tayyor" o'tishini qila oladi — ishlab chiqarish tugaganini birinchi
    # u biladi (2026-09-05, foydalanuvchi qarori).
    if not has_perm("orders.manage"):
        if not (has_perm("orders.status") and o.status == STATUS_PRODUCTION
                and request.form.get("status") == STATUS_READY):
            flash("Bu bo'limga kirish huquqingiz yo'q.", "danger")
            return redirect(url_for("orders.order_detail", order_id=order_id))

    try:
        new_status = parse_choice(request.form.get("status"), "Holat", ORDER_STATUSES)
    except ValidationError as e:
        flash(str(e), "danger")
        return redirect(url_for("orders.order_detail", order_id=order_id))

    if not can_transition(o.status, new_status):
        allowed = ", ".join(ALLOWED_TRANSITIONS.get(o.status, [])) or "yo'q"
        flash(
            f"'{o.status}' holatidan '{new_status}' holatiga o'tib bo'lmaydi. "
            f"Ruxsat etilgan: {allowed}.", "danger",
        )
        return redirect(url_for("orders.order_detail", order_id=order_id))

    if new_status == STATUS_CANCELLED and o.paid_amount_calc > ZERO:
        flash(
            "To'lov qilingan buyurtmani bekor qilib bo'lmaydi. "
            "Avval to'lovlarni qaytarib, yozuvlarni o'chiring.", "danger",
        )
        return redirect(url_for("orders.order_detail", order_id=order_id))

    # Bekor qilishda sabab majburiy (2026-09-07, foydalanuvchi qarori) —
    # barcha jarayonlar tasdiqlanib, oxir-oqibat to'lovsiz atkaz bo'lib
    # qolishi mumkin, shu holatlarda nima uchunligi yozib qo'yilsin.
    cancel_reason = None
    if new_status == STATUS_CANCELLED:
        try:
            cancel_reason = parse_text(
                request.form.get("cancel_reason"), "Bekor qilish sababi",
                required=True, max_length=500,
            )
        except ValidationError as e:
            flash(str(e), "danger")
            return redirect(url_for("orders.order_detail", order_id=order_id))

    old = o.status
    o.status = new_status
    if new_status == STATUS_CANCELLED:
        o.cancel_reason = cancel_reason
    elif old == STATUS_CANCELLED:
        # "bekor qilindi"dan qaytadan tiklanganda eski sabab endi ma'nosiz
        o.cancel_reason = None
    log_action(current_user, "status", "order", o.id, f"{old} -> {new_status}"
               + (f" ({cancel_reason})" if cancel_reason else ""))
    db.session.commit()
    flash("Holat yangilandi.", "success")
    return redirect(url_for("orders.order_detail", order_id=order_id))


def _active_xarajatchi():
    return (
        User.query.filter_by(role="xarajatchi", is_active_user=True)
        .order_by(User.username).all()
    )


def _active_boss():
    """Karta to'lovi tasdiqlanadigan boshliqlar (2026-09-08)."""
    return (
        User.query.filter_by(role="boss", is_active_user=True)
        .order_by(User.username).all()
    )


def _resolve_handover_target(pool, form, field_name):
    """Pul topshiriladigan foydalanuvchini aniqlaydi (naqd — xarajatchi,
    karta — boshliq — chaqiruvchi mos `pool`ni beradi).

    Mos rolda faol foydalanuvchi bitta bo'lsa — avtomatik shunga. Bir
    nechta bo'lsa — formadagi `field_name`dan (forma buni faqat shunday
    holatda ko'rsatadi). Hech biri aniqlanmasa `None` — topshiriq
    tayinlanmagan holda yoziladi, keyin admin "Pullar" bo'limida qo'lda
    tayinlaydi.
    """
    if len(pool) == 1:
        return pool[0]
    if len(pool) > 1:
        target_id = form.get(field_name, type=int)
        return next((x for x in pool if x.id == target_id), None)
    return None


@orders_bp.route("/<int:order_id>/tolov", methods=["POST"])
@login_required
@permission_required("orders.manage")
def add_payment(order_id):
    o = Order.query.get_or_404(order_id)
    guard = _guard_order_owner(o)
    if guard:
        return guard

    if o.status == STATUS_CANCELLED:
        flash("Bekor qilingan buyurtmaga to'lov qo'shib bo'lmaydi.", "danger")
        return redirect(url_for("orders.order_detail", order_id=order_id))

    try:
        amount = parse_money(request.form.get("amount"), "Summa", min_value=Decimal("0.01"))
        paid_on = parse_date(request.form.get("paid_on"), "To'lov sanasi", required=False) or today_local()
        note = parse_text(request.form.get("note"), "Izoh", required=False, max_length=255)
        payment_method = parse_choice(
            request.form.get("payment_method"), "To'lov usuli", ORDER_PAYMENT_METHODS
        )
    except ValidationError as e:
        flash(str(e), "danger")
        return redirect(url_for("orders.order_detail", order_id=order_id))

    if paid_on > today_local():
        flash("To'lov sanasi kelajakda bo'lishi mumkin emas.", "danger")
        return redirect(url_for("orders.order_detail", order_id=order_id))

    # Sahifa bir necha soniya qotib qolganda ikkinchi marta bosilib,
    # bitta to'lov ikki marta yozilib qolmasligi uchun — shu buyurtmaga
    # so'nggi to'lovdan beri kamida 1 daqiqa o'tgan bo'lishi kerak.
    last_payment = (
        Payment.query.filter_by(order_id=o.id)
        .order_by(Payment.created_at.desc())
        .first()
    )
    if last_payment and last_payment.created_at:
        elapsed = (now_local() - last_payment.created_at).total_seconds()
        if elapsed < PAYMENT_COOLDOWN_SECONDS:
            wait = int(PAYMENT_COOLDOWN_SECONDS - elapsed) + 1
            flash(
                f"Bu buyurtmaga hozirgina to'lov kiritildi. Takroriy (bexosdan "
                f"ikki marta yuborilgan) to'lovning oldini olish uchun yana "
                f"{wait} soniya kuting va qayta urinib ko'ring.", "warning",
            )
            return redirect(url_for("orders.order_detail", order_id=order_id))

    # Naqd/karta pul kimga topshirilishini (kimga "topshirilishi" yoki
    # kimning kartasiga tushishini) — bir nechta faol xarajatchi/boshliq
    # bo'lsa — oldindan aniqlaymiz (to'lovni bloklamaydi, faqat aniqlanmasa
    # topshiriq tayinlanmagan holda yoziladi). Karta — mijoz to'g'ridan-
    # to'g'ri boshliqning shaxsiy kartasiga o'tkazadi, shuning uchun naqd
    # kabi tasdiqlash talab qilinadi (2026-09-08, foydalanuvchi qarori).
    handover_channel = None
    handover_target = None
    if payment_method == CASH_PAYMENT_METHOD:
        handover_channel = HANDOVER_CHANNEL_CASH
        handover_target = _resolve_handover_target(_active_xarajatchi(), request.form, "xarajatchi_id")
    elif payment_method == CARD_PAYMENT_METHOD:
        handover_channel = HANDOVER_CHANNEL_CARD
        handover_target = _resolve_handover_target(_active_boss(), request.form, "boss_id")

    # Qarzdan ko'p to'lash mumkin — ortiqchasi mijozning avansi (zapas puli)
    # bo'lib qoladi. Faqat ogohlantiramiz, bloklamaymiz.
    p = Payment(
        order_id=o.id, amount=amount, paid_on=paid_on, note=note,
        payment_method=payment_method, created_by=current_user.id,
    )
    db.session.add(p)
    db.session.flush()

    # Naqd/karta to'lov — "Pullar" bo'limida kimga topshirilgani/kimning
    # kartasiga tushgani avtomatik qayd etiladi (2026-09-07/08, foydalanuvchi
    # qarori). Bu SOF QO'SHIMCHA kuzatuv — moliyaviy hisob-kitobga ta'sir qilmaydi.
    if handover_channel:
        db.session.add(CashHandover(
            payment_id=p.id, order_id=o.id, amount=amount,
            from_user_id=current_user.id,
            to_user_id=handover_target.id if handover_target else None,
            status=HANDOVER_PENDING,
            channel=handover_channel,
        ))
        if not handover_target:
            who = "ish boshqaruvchiga" if handover_channel == HANDOVER_CHANNEL_CASH else "boshliqqa"
            flash(
                f"Diqqat: pul kimga topshirilgani/kimning kartasiga tushgani aniqlanmadi — "
                f"«Pullar» bo'limida admin qo'lda tayinlashi kerak ({who}).", "warning",
            )

    log_action(current_user, "payment", "order", o.id, f"{amount} so'm to'lov")
    db.session.commit()
    notify_payment(o, amount)

    overpaid = o.overpaid
    if overpaid > ZERO:
        flash(
            f"To'lov qayd etildi. Ortiqcha {money_str(overpaid)} so'm "
            f"mijozning avansi sifatida qoldi.", "warning",
        )
    else:
        flash("To'lov qayd etildi.", "success")
    return redirect(url_for("orders.order_detail", order_id=order_id))


@orders_bp.route("/tolov/<int:payment_id>/ochirish", methods=["POST"])
@login_required
@permission_required("orders.delete")
def delete_payment(payment_id):
    p = Payment.query.get_or_404(payment_id)
    guard = _guard_order_owner(p.order)
    if guard:
        return guard
    order_id = p.order_id
    log_action(current_user, "payment_delete", "order", order_id, f"{p.amount} so'm to'lov o'chirildi")
    db.session.delete(p)
    db.session.commit()
    flash("To'lov yozuvi o'chirildi.", "success")
    return redirect(url_for("orders.order_detail", order_id=order_id))


# ---------- buyurtmani o'chirish (yumshoq) ----------

@orders_bp.route("/<int:order_id>/ochirish", methods=["POST"])
@login_required
@permission_required("orders.delete")
def delete_order(order_id):
    o = Order.query.get_or_404(order_id)

    if o.paid_amount_calc > ZERO:
        flash(
            "To'lov qilingan buyurtmani o'chirib bo'lmaydi. "
            "Avval to'lov yozuvlarini o'chiring.", "danger",
        )
        return redirect(url_for("orders.order_detail", order_id=order_id))

    # Bu buyurtmaga ombordan sarflangan (chiqim qilingan) mahsulotlar bo'lsa —
    # buyurtma o'chirilganda ular avtomatik omborga qaytariladi (2026-09-07,
    # foydalanuvchi qarori): ish boshqaruvchi xato buyurtmaga xarajat kiritib
    # qo'yishi, keyin admin buyurtmani o'chirishi mumkin — bu holda mahsulot
    # omborda "yo'qolib" qolmasligi kerak. Asl chiqim yozuvi tarix uchun
    # saqlanadi, unga teng miqdorda qarshi KIRIM yoziladi (Material.quantity
    # barcha kirim/chiqim yozuvlari yig'indisidan hisoblanadi).
    returned = []
    for mv in o.stock_moves:
        if mv.kind != STOCK_OUT:
            continue
        db.session.add(StockMove(
            material_id=mv.material_id, kind=STOCK_IN,
            quantity=mv.quantity, unit_price=mv.unit_price,
            moved_on=today_local(), order_id=o.id,
            note=f"Buyurtma {o.order_number} o'chirilgani uchun omborga qaytarildi",
            created_by=current_user.id,
        ))
        returned.append(f"{mv.material.name} {qty_str(mv.quantity)} {mv.material.unit}")

    o.is_deleted = True
    o.deleted_at = now_local()
    o.deleted_by = current_user.id
    log_action(
        current_user, "delete", "order", o.id,
        f"{o.order_number} o'chirildi"
        + (f" — omborga qaytarildi: {', '.join(returned)}" if returned else ""),
    )
    db.session.commit()
    if returned:
        flash(
            f"Buyurtma {o.order_number} o'chirildi. {len(returned)} ta mahsulot "
            f"omborga qaytarildi: {', '.join(returned)}.", "success",
        )
    else:
        flash(f"Buyurtma {o.order_number} o'chirildi. Kerak bo'lsa tiklash mumkin.", "success")
    return redirect(url_for("orders.list_orders"))


@orders_bp.route("/<int:order_id>/tiklash", methods=["POST"])
@login_required
@permission_required("orders.delete")
def restore_order(order_id):
    o = Order.query.get_or_404(order_id)

    # O'chirilganda ombordan sarflangan mahsulot qaytarilgan bo'lishi mumkin
    # (yuqoridagi delete_order) — tiklanganda buni eslatamiz, chunki
    # ishlab chiqarish davom etsa, xarajat qayta kiritilishi kerak bo'ladi.
    had_returns = any(
        mv.kind == STOCK_IN and mv.note and "o'chirilgani uchun omborga qaytarildi" in mv.note
        for mv in o.stock_moves
    )

    o.is_deleted = False
    o.deleted_at = None
    o.deleted_by = None
    log_action(current_user, "restore", "order", o.id, f"{o.order_number} tiklandi")
    db.session.commit()
    flash(f"Buyurtma {o.order_number} tiklandi.", "success")
    if had_returns:
        flash(
            "Diqqat: bu buyurtma o'chirilganda ombordan sarflangan mahsulot "
            "omborga qaytarilgan edi. Agar ishlab chiqarish davom etsa, "
            "xarajatni qaytadan kiriting.", "warning",
        )
    return redirect(url_for("orders.order_detail", order_id=order_id))


@orders_bp.route("/ochirilganlar")
@login_required
@permission_required("orders.delete")
def deleted_orders():
    orders = eager_orders(
        Order.query.filter(Order.is_deleted.is_(True)).order_by(Order.deleted_at.desc())
    ).all()
    return render_template("orders/deleted.html", orders=orders)


# ---------- fayl biriktirish ----------

@orders_bp.route("/<int:order_id>/fayl", methods=["POST"])
@login_required
@permission_required("orders.edit")
def upload_file(order_id):
    o = Order.query.get_or_404(order_id)
    guard = _guard_order_owner(o)
    if guard:
        return guard
    uploaded = request.files.get("file")

    if not uploaded or not uploaded.filename:
        flash("Fayl tanlanmagan.", "danger")
        return redirect(url_for("orders.order_detail", order_id=order_id))

    original = uploaded.filename
    ext = os.path.splitext(original)[1].lower()
    if ext not in current_app.config["ALLOWED_EXTENSIONS"]:
        allowed = ", ".join(sorted(current_app.config["ALLOWED_EXTENSIONS"]))
        flash(f"Bu turdagi fayl qabul qilinmaydi. Ruxsat etilgan: {allowed}", "danger")
        return redirect(url_for("orders.order_detail", order_id=order_id))

    upload_dir = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_dir, exist_ok=True)

    stored_name = f"{uuid.uuid4().hex}{ext}"
    path = os.path.join(upload_dir, stored_name)
    uploaded.save(path)
    size = os.path.getsize(path)

    f = OrderFile(
        order_id=o.id,
        filename=stored_name,
        original_name=secure_filename(original)[:255] or f"fayl{ext}",
        size_bytes=size,
        created_by=current_user.id,
    )
    db.session.add(f)
    log_action(current_user, "file_upload", "order", o.id, original[:100])
    db.session.commit()
    flash("Fayl biriktirildi.", "success")
    return redirect(url_for("orders.order_detail", order_id=order_id))


@orders_bp.route("/fayl/<int:file_id>/yuklab-olish")
@login_required
@permission_required("orders.view")
def download_file(file_id):
    f = OrderFile.query.get_or_404(file_id)
    guard = _guard_order_owner(f.order)
    if guard:
        return guard
    return send_from_directory(
        current_app.config["UPLOAD_FOLDER"],
        f.filename,
        as_attachment=True,
        download_name=f.original_name,
    )


@orders_bp.route("/fayl/<int:file_id>/ochirish", methods=["POST"])
@login_required
@permission_required("orders.delete")
def delete_file(file_id):
    f = OrderFile.query.get_or_404(file_id)
    order_id = f.order_id
    path = os.path.join(current_app.config["UPLOAD_FOLDER"], f.filename)
    if os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            pass
    log_action(current_user, "file_delete", "order", order_id, f.original_name[:100])
    db.session.delete(f)
    db.session.commit()
    flash("Fayl o'chirildi.", "success")
    return redirect(url_for("orders.order_detail", order_id=order_id))

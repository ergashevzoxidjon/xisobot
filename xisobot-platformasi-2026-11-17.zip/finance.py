import io
from decimal import Decimal

from flask import (
    Blueprint, render_template, request, redirect, url_for, flash,
    current_app, send_file,
)
from flask_login import login_required, current_user
from sqlalchemy import func

from sqlalchemy.orm import joinedload, selectinload

from extensions import db
from models import (
    Expense, Order, OrderItem, Payment, Client, Material, StockMove, log_action,
    EXPENSE_CATEGORIES, GENERAL_EXPENSE_CATEGORIES, EXPENSE_ORDER_CATEGORY,
    STATUS_CANCELLED, STOCK_OUT, ZERO, PAYMENT_TRANSFER, PAYMENT_CASH,
    ORDER_PAYMENT_COMPANY_METHODS, CASH_SOURCE_OFFICE, TAXI_EXPENSE_CATEGORY,
    Supplier, STOCK_UNITS, CASH_SOURCE_LABELS, PAYER_COMPANIES,
)
from permissions import permission_required, has_perm
from queries import (
    top_debtors, eager_orders, materials_with_stock,
    suppliers_with_stats, all_managers_month_summary,
)
from stock import consume, shortage, _confirmed_handovers_for
from utils import (
    ValidationError, parse_money, parse_date, parse_text, parse_choice, parse_int,
    parse_qty, to_money, to_qty, today_local, month_bounds, money_str, qty_str, QTY_ZERO,
)

finance_bp = Blueprint("finance", __name__, url_prefix="/moliya")

UZ_MONTHS = [
    "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
    "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr",
]


# ---------- umumiy hisob-kitob funksiyalari ----------

def income_between(start, end):
    """Tushum — AYNAN to'lov sanasi bo'yicha (buyurtma sanasi bo'yicha emas).
    Bekor qilingan buyurtmalar hisobga olinmaydi."""
    total = (
        db.session.query(func.coalesce(func.sum(Payment.amount), 0))
        .join(Order, Payment.order_id == Order.id)
        .filter(
            Payment.paid_on >= start,
            Payment.paid_on < end,
            Order.status != STATUS_CANCELLED,
            Order.is_deleted.is_(False),
        )
        .scalar()
    )
    return to_money(total)


def income_by_method(start, end):
    """Tushum — to'lov usuli bo'yicha taqsimlangan (Naqd/Karta/Terminal/Birja
    va "Dogovor ..." — korxonalar). Moliyaviy hisobotdagi "Korxonalar
    bo'yicha tushum" bloki uchun (2026-08-30, foydalanuvchi qarori).
    Bekor qilingan/o'chirilgan buyurtmalar hisobga olinmaydi.

    Har bir qator bilan birga bugungi kun bo'yicha tushum ham alohida
    ustunda ko'rsatilishi uchun hisoblab qo'shiladi (2026-09-06,
    foydalanuvchi qarori) — yillik jamidan farqli, real kalendar sanasi
    "bugun"ga tegishli to'lovlar summasi."""
    rows = (
        db.session.query(Payment.payment_method, func.coalesce(func.sum(Payment.amount), 0))
        .join(Order, Payment.order_id == Order.id)
        .filter(
            Payment.paid_on >= start,
            Payment.paid_on < end,
            Order.status != STATUS_CANCELLED,
            Order.is_deleted.is_(False),
        )
        .group_by(Payment.payment_method)
        .order_by(func.sum(Payment.amount).desc())
        .all()
    )

    today = today_local()
    today_rows = (
        db.session.query(Payment.payment_method, func.coalesce(func.sum(Payment.amount), 0))
        .join(Order, Payment.order_id == Order.id)
        .filter(
            Payment.paid_on == today,
            Order.status != STATUS_CANCELLED,
            Order.is_deleted.is_(False),
        )
        .group_by(Payment.payment_method)
        .all()
    )
    today_map = {m: to_money(t) for m, t in today_rows}

    return [
        {
            "method": m or "Ko'rsatilmagan",
            "total": to_money(t),
            "is_company": m in ORDER_PAYMENT_COMPANY_METHODS,
            "today_total": today_map.get(m, ZERO),
        }
        for m, t in rows
    ]


def expenses_between(start, end):
    total = (
        db.session.query(func.coalesce(func.sum(Expense.amount), 0))
        .filter(Expense.date >= start, Expense.date < end)
        .scalar()
    )
    return to_money(total)


def year_rows(year):
    rows = []
    for m in range(1, 13):
        start, end = month_bounds(year, m)
        income = income_between(start, end)
        expense = expenses_between(start, end)
        rows.append({
            "name": UZ_MONTHS[m - 1],
            "month": m,
            "income": income,
            "expense": expense,
            "profit": income - expense,
        })
    return rows


# ---------- xarajatlar ----------

MAX_EXPENSE_ROWS = 30


def parse_expense_order(form):
    """Formadagi buyurtma tanlovini o'qiydi. Bo'sh bo'lsa — umumiy xarajat."""
    raw = (form.get("order_id") or "").strip()
    if not raw:
        return None
    order_id = parse_int(raw, "Buyurtma", min_value=1)
    order = db.session.get(Order, order_id)
    if not order or order.is_deleted:
        raise ValidationError("Buyurtma: tanlangan buyurtma topilmadi.")
    return order


def expense_rows_from_form(form, require_material=False, allow_empty=False):
    """Formadagi xarajat qatorlarini o'qiydi: mahsulot, soni, narxi.

    Jami avtomatik hisoblanadi (soni × narxi). Qator ombordagi mahsulotga
    tegishli bo'lsa `material` to'ladi — bunday qator yangi xarajat emas,
    ombordan chiqim sifatida yoziladi (puli kirimda allaqachon yozilgan).

    `require_material=True` bo'lsa (buyurtma xarajati) ombordan tanlanmagan
    qator qabul qilinmaydi — avval mahsulot omborga kirim qilinishi kerak.
    """
    material_ids = form.getlist("expense_material")
    descriptions = form.getlist("expense_description")
    quantities = form.getlist("expense_quantity")
    prices = form.getlist("expense_unit_price")

    count = max(len(material_ids), len(descriptions), len(quantities), len(prices))
    if count > MAX_EXPENSE_ROWS:
        raise ValidationError(f"Bir marta {MAX_EXPENSE_ROWS} tadan ko'p qator kiritib bo'lmaydi.")

    def cell(values, index):
        return (values[index] if index < len(values) else "").strip()

    rows = []
    for index in range(count):
        raw_id = cell(material_ids, index)
        description = cell(descriptions, index)
        qty_text = cell(quantities, index)
        price_text = cell(prices, index)

        # Faqat "soni" (standart 1) to'ldirilgan qator — bo'sh qator: forma
        # har doim bitta qatorni soni=1 bilan ochadi, taksi yolg'iz
        # kiritilganda u xato bermasligi kerak.
        if not raw_id and not description and not price_text:
            continue

        row = index + 1
        material = None
        if raw_id:
            material = db.session.get(Material, int(raw_id)) if raw_id.isdigit() else None
            if material is None:
                raise ValidationError(f"{row}-qator: mahsulot topilmadi.")
        elif description:
            # foydalanuvchi ro'yxatdan tanlamay, nomini yozgan bo'lishi mumkin
            material = Material.query.filter(Material.name.ilike(description)).first()

        if material is None and require_material:
            raise ValidationError(
                f"{row}-qator: «{description or '—'}» omborda yo'q. "
                f"Avval Ombor → Kirim orqali qabul qiling."
            )

        quantity = parse_qty(qty_text or "1", f"{row}-qator, soni",
                             min_value=Decimal("0.001"))
        unit_price = parse_money(price_text, f"{row}-qator, narxi",
                                 min_value=Decimal("0.01"))

        rows.append({
            "material": material,
            "description": material.name if material else parse_text(
                description, f"{row}-qator, nomi", required=True, max_length=255),
            "quantity": quantity,
            "unit_price": unit_price,
            "amount": to_money(quantity * unit_price),
        })

    if not rows and not allow_empty:
        raise ValidationError("Kamida bitta xarajat qatorini to'ldiring.")
    return rows


def taxi_from_form(form):
    """Xarajat formasidagi "Taksi" qatori (2026-11-17, foydalanuvchi so'rovi).

    Ilgari taksi pulini yozish uchun "Taksi"ni ombor mahsuloti qilib, avval
    kirim, keyin chiqim qilishga to'g'ri kelardi. Endi belgi qo'yiladi,
    nechta qatnov va bittasining narxi yoziladi — omborga tegmaydi.
    Belgi qo'yilmagan bo'lsa `None` qaytaradi.
    """
    if form.get("taxi_enabled") != "1":
        return None
    count = parse_int(form.get("taxi_count") or "1", "Taksi, soni", min_value=1)
    unit_price = parse_money(form.get("taxi_price"), "Taksi, narxi",
                             min_value=Decimal("0.01"))
    return {"count": count, "unit_price": unit_price,
            "amount": to_money(unit_price * count)}


def record_taxi(taxi, order, exp_date):
    """Taksi xarajatini yozadi: "transport" turkumi, pul OFIS kassasidan.

    Buyurtmaga bog'langan bo'lsa o'sha buyurtma tannarxiga ham kiradi
    (`Order.direct_expenses`), hisobotda esa "transport" turkumida ko'rinadi.
    OFIS balansi (`queries.office_balance`) shu yozuvni avtomatik ayiradi.
    """
    e = Expense(
        category=TAXI_EXPENSE_CATEGORY, amount=taxi["amount"],
        description=f"Taksi — {taxi['count']} ta × {money_str(taxi['unit_price'])} so'm",
        date=exp_date, order_id=order.id if order else None,
        is_paid=True, payment_method=PAYMENT_CASH, cash_source=CASH_SOURCE_OFFICE,
        created_by=current_user.id,
    )
    db.session.add(e)
    db.session.flush()
    log_action(current_user, "create", "expense", e.id,
               f"taksi — {taxi['amount']} (OFIS)"
               + (f" ({order.order_number})" if order else ""))
    return e


def stock_shortages(rows):
    """Qatorlardagi mahsulotlar bo'yicha yetishmayotgan miqdorlar ro'yxati.

    Bir mahsulot bir necha qatorda kelsa, miqdorlar qo'shib tekshiriladi.
    Yozuvdan OLDIN chaqiriladi — aks holda yangi chiqimlar qoldiqni buzadi.
    """
    needed = {}
    for data in rows:
        material = data["material"]
        if material is not None:
            needed[material] = needed.get(material, QTY_ZERO) + data["quantity"]

    messages = []
    for material, qty in needed.items():
        missing = shortage(material, qty)
        if missing > QTY_ZERO:
            messages.append(
                f"«{material.name}»: omborda {qty_str(material.quantity)} {material.unit} "
                f"bor, {qty_str(missing)} {material.unit} yetishmadi — qoldiq minusga o'tdi."
            )
    return messages


def expense_category(form, order):
    """Buyurtmaga bog'langan xarajat turkumi avtomatik qo'yiladi.

    Foydalanuvchi turkumni faqat umumiy xarajatlar uchun tanlaydi —
    buyurtma xarajatida bu maydon ko'rinmaydi.
    """
    if order is not None:
        return EXPENSE_ORDER_CATEGORY
    return parse_choice(form.get("category"), "Turkum", GENERAL_EXPENSE_CATEGORIES)


@finance_bp.route("/xarajatlar")
@login_required
@permission_required("expenses.view")
def expenses_list():
    page = request.args.get("page", 1, type=int)
    category = request.args.get("category", "")

    query = Expense.query.options(
        joinedload(Expense.order).joinedload(Order.client)
    )
    if category and category in EXPENSE_CATEGORIES:
        query = query.filter(Expense.category == category)

    pagination = query.order_by(Expense.date.desc(), Expense.id.desc()).paginate(
        page=page, per_page=current_app.config["PER_PAGE"], error_out=False
    )

    total_query = db.session.query(func.coalesce(func.sum(Expense.amount), 0))
    if category and category in EXPENSE_CATEGORIES:
        total_query = total_query.filter(Expense.category == category)
    total_all = to_money(total_query.scalar())

    # Perechisleniye qilingan xaridlar — qaysi tashkilot hisobidan qancha
    # to'langani (ombor kirimidan kelgan xarajatlar bo'yicha, umumiy —
    # filtrga qaramay, xuddi taminotchi qarzi kabi doimiy ko'rinadi).
    transfer_rows = (
        db.session.query(Expense.paid_via, func.coalesce(func.sum(Expense.amount), 0))
        .filter(Expense.payment_method == PAYMENT_TRANSFER)
        .group_by(Expense.paid_via)
        .order_by(func.sum(Expense.amount).desc())
        .all()
    )
    transfer_totals = [{"company": c or "Noma'lum", "total": to_money(t)} for c, t in transfer_rows]
    transfer_total_all = sum((row["total"] for row in transfer_totals), ZERO)

    return render_template(
        "finance/expenses.html",
        expenses=pagination.items,
        pagination=pagination,
        # Filtr tugmalarida "buyurtma" ko'rsatilmaydi — u avtomatik qo'yiladigan
        # ichki turkum, foydalanuvchi tanlamaydi (2026-08-27, foydalanuvchi qarori).
        categories=GENERAL_EXPENSE_CATEGORIES,
        category=category,
        total_all=total_all,
        transfer_totals=transfer_totals,
        transfer_total_all=transfer_total_all,
    )


@finance_bp.route("/xarajatlar/yangi", methods=["GET", "POST"])
@login_required
@permission_required("expenses.create")
def new_expense():
    if request.method == "POST":
        order = None
        try:
            order = parse_expense_order(request.form)
            category = expense_category(request.form, order)
            taxi = taxi_from_form(request.form)
            # Buyurtma xarajatida mahsulot faqat ombordan olinadi. Taksi
            # belgilangan bo'lsa, mahsulot qatorlari bo'sh qolishi mumkin.
            rows = expense_rows_from_form(request.form, require_material=order is not None,
                                          allow_empty=taxi is not None)
            exp_date = parse_date(request.form.get("date"), "Sana", required=False) or today_local()
        except ValidationError as e:
            flash(str(e), "danger")
            return _expense_page(selected_order=order, expense=None, form=request.form)

        if exp_date > today_local():
            flash("Xarajat sanasi kelajakda bo'lishi mumkin emas.", "danger")
            return _expense_page(selected_order=order, expense=None, form=request.form)

        # yozuvdan oldin: qoldiq yetadimi
        warnings = stock_shortages(rows)

        total = ZERO
        from_stock = 0
        direct = 0
        for data in rows:
            if data["material"] is not None:
                # ombordan chiqim — puli kirimda yozilgan, yangi xarajat yo'q
                consume(data["material"], data["quantity"], data["unit_price"],
                        order, exp_date)
                from_stock += 1
            else:
                e = Expense(category=category, amount=data["amount"],
                            description=data["description"], date=exp_date,
                            order_id=order.id if order else None,
                            created_by=current_user.id)
                db.session.add(e)
                db.session.flush()
                log_action(current_user, "create", "expense", e.id,
                           f"{category} — {data['amount']}"
                           + (f" ({order.order_number})" if order else ""))
                direct += 1
            total += data["amount"]

        if taxi:
            record_taxi(taxi, order, exp_date)
            total += taxi["amount"]

        db.session.commit()
        for message in warnings:
            flash(message, "warning")

        parts = []
        if from_stock:
            parts.append(f"{from_stock} ta mahsulot ombordan sarflandi")
        if direct:
            parts.append(f"{direct} ta xarajat yozildi")
        if taxi:
            parts.append(f"taksi {money_str(taxi['amount'])} so'm OFIS kassasidan")
        summary = ", ".join(parts) + f" — jami {money_str(total)} so'm."

        if order:
            flash(f"{order.order_number}: {summary}", "success")
            return redirect(url_for("orders.order_detail", order_id=order.id))
        flash(summary[0].upper() + summary[1:], "success")
        if from_stock and not direct and not taxi:
            return redirect(url_for("stock.list_materials"))
        return redirect(url_for("finance.expenses_list"))

    # Buyurtma sahifasidagi "Xarajat qo'shish" tugmasi o'sha buyurtmani tanlab beradi
    preselected_id = request.args.get("order_id", type=int)
    selected_order = None
    if preselected_id:
        selected_order = (
            Order.query.options(
                joinedload(Order.client), selectinload(Order.items), joinedload(Order.creator)
            )
            .get(preselected_id)
        )
    return _expense_page(selected_order=selected_order, expense=None, form=None)


def _expense_page(selected_order, expense, form):
    """Xarajat formasi — o'ng tomonda ombordagi mahsulotlar ustuni bilan.

    `stock.manage` ruxsati bo'lsa, formadan chiqmasdan omborga tezkor kirim
    qilish oynasi uchun kerakli ro'yxatlar ham beriladi (2026-11-17).
    """
    quick = {}
    if has_perm("stock.manage"):
        quick = dict(
            units=STOCK_UNITS,
            suppliers=Supplier.query.filter_by(is_active=True, is_deleted=False)
                                    .order_by(Supplier.name).all(),
            cash_handovers=_confirmed_handovers_for(current_user),
            cash_source_labels=CASH_SOURCE_LABELS,
            payer_companies=PAYER_COMPANIES,
        )
    return render_template(
        "finance/expense_form.html",
        categories=GENERAL_EXPENSE_CATEGORIES,
        materials=materials_with_stock(only_active=True),
        selected_order=selected_order, expense=expense, form=form,
        quick_receive=bool(quick), **quick,
    )


@finance_bp.route("/xarajatlar/<int:expense_id>/tahrirlash", methods=["GET", "POST"])
@login_required
@permission_required("expenses.create")
def edit_expense(expense_id):
    e = Expense.query.get_or_404(expense_id)

    if request.method == "POST":
        try:
            order = parse_expense_order(request.form)
            category = expense_category(request.form, order)
            rows = expense_rows_from_form(request.form)
            exp_date = parse_date(request.form.get("date"), "Sana", required=False) or e.date
        except ValidationError as err:
            db.session.rollback()
            flash(str(err), "danger")
            return _expense_page(selected_order=e.order, expense=e, form=request.form)

        # Tahrirlashda bitta yozuv o'zgaradi — birinchi qator hisobga olinadi
        e.order_id = order.id if order else None
        e.category = category
        e.amount = rows[0]["amount"]
        e.description = rows[0]["description"]
        e.date = exp_date

        log_action(current_user, "update", "expense", e.id, f"{e.category} — {e.amount}")
        db.session.commit()
        flash("Xarajat yangilandi.", "success")
        if e.order_id:
            return redirect(url_for("orders.order_detail", order_id=e.order_id))
        return redirect(url_for("finance.expenses_list"))

    return _expense_page(selected_order=e.order, expense=e, form=None)


# ---------- buyurtmaga ombordan chiqim sifatida yozilgan xarajatni tuzatish ----------
# (2026-09-07, foydalanuvchi qarori): "Xarajat kiritish" buyurtma uchun
# har doim ombordan mahsulot tanlashni talab qiladi (require_material=True,
# yuqoridagi expense_rows_from_form) — shuning uchun bunday qatorlar
# `Expense` emas, balki `StockMove(OUT)` sifatida yoziladi va yuqoridagi
# edit_expense() ularga tegishli emas. Ish boshqaruvchi xato kiritsa,
# to'g'irlay olishi uchun alohida route kerak.

@finance_bp.route("/xarajatlar/ombor/<int:move_id>/tahrirlash", methods=["GET", "POST"])
@login_required
@permission_required("expenses.create")
def edit_stock_expense(move_id):
    move = StockMove.query.get_or_404(move_id)
    if move.kind != STOCK_OUT or not move.order_id:
        flash("Bu yozuvni bu yerdan tahrirlab bo'lmaydi.", "danger")
        return redirect(url_for("finance.expenses_list"))
    order = move.order
    if order and order.is_deleted:
        flash("O'chirilgan buyurtmaning xarajatini tahrirlab bo'lmaydi.", "danger")
        return redirect(url_for("orders.order_detail", order_id=order.id))

    if request.method == "POST":
        try:
            raw_material = (request.form.get("material_id") or "").strip()
            material = db.session.get(Material, int(raw_material)) if raw_material.isdigit() else None
            if material is None:
                raise ValidationError("Mahsulot tanlanmagan.")
            quantity = parse_qty(request.form.get("quantity"), "Soni", min_value=Decimal("0.001"))
            unit_price = parse_money(request.form.get("unit_price"), "Narxi", min_value=Decimal("0.01"))
            moved_on = parse_date(request.form.get("moved_on"), "Sana", required=False) or move.moved_on
        except ValidationError as err:
            flash(str(err), "danger")
            return render_template("finance/stock_expense_form.html", move=move, order=order,
                                   materials=materials_with_stock(only_active=True))

        if moved_on > today_local():
            flash("Sana kelajakda bo'lishi mumkin emas.", "danger")
            return render_template("finance/stock_expense_form.html", move=move, order=order,
                                   materials=materials_with_stock(only_active=True))

        old_desc = f"{move.material.name}: {qty_str(move.quantity)} {move.material.unit} × {money_str(move.unit_price)}"

        # Qoldiq yetarlimi — bu qatorning eski ta'sirini vaqtincha qaytarib
        # hisoblaymiz (o'zi bilan taqqoslab, yolg'on yetishmovchilik chiqmasin).
        if material.id == move.material_id:
            available = material.quantity + to_qty(move.quantity)
        else:
            available = material.quantity
        missing = to_qty(quantity) - available
        if missing > QTY_ZERO:
            flash(
                f"«{material.name}»: omborda {qty_str(available)} {material.unit} bor, "
                f"{qty_str(missing)} {material.unit} yetishmadi — qoldiq minusga o'tdi.",
                "warning",
            )

        move.material_id = material.id
        move.quantity = quantity
        move.unit_price = unit_price
        move.moved_on = moved_on

        new_desc = f"{material.name}: {qty_str(quantity)} {material.unit} × {money_str(unit_price)}"
        log_action(current_user, "update", "stock_out", move.id,
                   f"{old_desc} -> {new_desc}" + (f" ({order.order_number})" if order else ""))
        db.session.commit()
        flash("Xarajat qatori yangilandi.", "success")
        return redirect(url_for("orders.order_detail", order_id=order.id))

    return render_template("finance/stock_expense_form.html", move=move, order=order,
                           materials=materials_with_stock(only_active=True))


@finance_bp.route("/xarajatlar/ombor/<int:move_id>/ochirish", methods=["POST"])
@login_required
@permission_required("expenses.create")
def delete_stock_expense(move_id):
    """Xato kiritilgan ombordan-chiqim xarajat qatorini butunlay o'chiradi.

    Mahsulot avtomatik omborga qaytadi — qoldiq kirim/chiqim yozuvlari
    yig'indisidan hisoblanadi, shuning uchun chiqim yozuvini o'chirish
    qoldiqni ko'taradi (yangi kirim yozish shart emas)."""
    move = StockMove.query.get_or_404(move_id)
    if move.kind != STOCK_OUT or not move.order_id:
        flash("Bu yozuvni bu yerdan o'chirib bo'lmaydi.", "danger")
        return redirect(url_for("finance.expenses_list"))
    order = move.order
    if order and order.is_deleted:
        flash("O'chirilgan buyurtmaning xarajatini o'chirib bo'lmaydi.", "danger")
        return redirect(url_for("orders.order_detail", order_id=order.id))

    desc = f"{move.material.name}: {qty_str(move.quantity)} {move.material.unit}"
    log_action(current_user, "delete", "stock_out", move.id,
               f"{desc}" + (f" ({order.order_number})" if order else "")
               + " — xato xarajat qatori o'chirildi, mahsulot omborga qaytdi")
    db.session.delete(move)
    db.session.commit()
    flash(f"Xarajat qatori o'chirildi — «{desc}» omborga qaytarildi.", "success")
    return redirect(url_for("orders.order_detail", order_id=order.id) if order else url_for("finance.expenses_list"))


# ---------- moliyaviy hisobot ----------

@finance_bp.route("/hisobot")
@login_required
@permission_required("reports.view")
def report():
    from models import User
    from utils import month_bounds as _month_bounds

    year = request.args.get("year", today_local().year, type=int)
    if year < 2000 or year > 2100:
        year = today_local().year

    months = year_rows(year)
    total_income = sum((m["income"] for m in months), ZERO)
    total_expense = sum((m["expense"] for m in months), ZERO)
    total_profit = total_income - total_expense

    start, end = date_range_for_year(year)

    # Menejerlar bo'yicha shu oylik ko'rsatkich — hisobotda ham ko'rinishi
    # kerak (2026-08-29, foydalanuvchi qarori).
    manager_rows = []
    if has_perm("managers.view"):
        today = today_local()
        m_start, m_end = _month_bounds(today.year, today.month)
        stats = all_managers_month_summary(m_start, m_end)
        managers = User.query.filter_by(role="menejer").order_by(User.username).all()
        manager_rows = [
            {
                "manager": m,
                "clients_count": stats.get(m.id, {}).get("clients_count", 0),
                "total_sum": stats.get(m.id, {}).get("total_sum", ZERO),
            }
            for m in managers
        ]

    supplier_debt_total = ZERO
    if has_perm("reports.view"):
        for s in suppliers_with_stats(only_active=True):
            supplier_debt_total += s.debt

    # To'lov usuli / korxonalar bo'yicha tushum — alohida blok
    # (2026-08-30, foydalanuvchi qarori).
    # Faqat shu blok uchun oy tanlash mumkin (bo'sh = butun yil).
    income_month = request.args.get("income_month", 0, type=int)
    if 1 <= income_month <= 12:
        i_start, i_end = _month_bounds(year, income_month)
    else:
        income_month = 0
        i_start, i_end = start, end
    income_totals = income_by_method(i_start, i_end)
    income_total_all = sum((row["total"] for row in income_totals), ZERO)
    income_company_total = sum(
        (row["total"] for row in income_totals if row["is_company"]), ZERO
    )
    income_today_total_all = sum((row["today_total"] for row in income_totals), ZERO)

    return render_template(
        "finance/report.html",
        months=months, year=year,
        total_income=total_income, total_expense=total_expense, total_profit=total_profit,
        manager_rows=manager_rows,
        supplier_debt_total=supplier_debt_total,
        income_totals=income_totals,
        income_month=income_month,
        income_total_all=income_total_all,
        income_company_total=income_company_total,
        income_today_total_all=income_today_total_all,
        **expense_breakdown(start, end),
    )


@finance_bp.route("/taminotchi-qarzlari")
@login_required
@permission_required("reports.view")
def supplier_debts():
    """Kimdan qancha qarzimiz borligi — alohida hisobot sahifasi
    (2026-08-29, foydalanuvchi qarori — boss suppliers.view huquqisiz
    ham shuni ko'ra olishi kerak)."""
    suppliers = suppliers_with_stats(only_active=True)
    total_debt = ZERO
    total_credit = ZERO
    for s in suppliers:
        total_debt += s.debt
        total_credit += s.credit

    debtors = sorted((s for s in suppliers if s.debt > ZERO), key=lambda s: s.debt, reverse=True)

    return render_template(
        "finance/supplier_debts.html",
        debtors=debtors, total_debt=total_debt, total_credit=total_credit,
        supplier_count=len(suppliers),
    )


def expense_breakdown(start, end):
    """Xarajatning uch kesimi: turkum, buyurtma va mahsulot turi.

    Ilgari alohida "Xarajat tahlili" sahifasi bo'lgan — moliyaviy hisobot
    bilan bir xil ishni qilgani uchun (2026-08-26) shu yerga ko'chirildi.
    """
    total = expenses_between(start, end)

    by_category = (
        db.session.query(
            Expense.category,
            func.coalesce(func.sum(Expense.amount), 0),
            func.count(Expense.id),
        )
        .filter(Expense.date >= start, Expense.date < end)
        .group_by(Expense.category)
        .order_by(func.sum(Expense.amount).desc())
        .all()
    )
    category_rows = [
        {"name": name, "amount": to_money(amount), "count": count}
        for name, amount, count in by_category
    ]

    # buyurtmaga bog'langan xarajatlar
    per_order = (
        db.session.query(Expense.order_id, func.coalesce(func.sum(Expense.amount), 0))
        .filter(Expense.date >= start, Expense.date < end, Expense.order_id.isnot(None))
        .group_by(Expense.order_id)
        .all()
    )
    order_expense = {order_id: to_money(amount) for order_id, amount in per_order}
    linked = sum(order_expense.values(), ZERO)
    general = total - linked

    # Ombordan sarflangan mahsulotlar. Ularning puli kirim paytida xarajat
    # sifatida yozilgan, shuning uchun `total` ga QO'SHILMAYDI — faqat
    # buyurtmaning tannarxiga kiradi.
    per_order_stock = (
        db.session.query(
            StockMove.order_id,
            func.coalesce(func.sum(StockMove.quantity * StockMove.unit_price), 0),
        )
        .filter(StockMove.moved_on >= start, StockMove.moved_on < end,
                StockMove.kind == STOCK_OUT, StockMove.order_id.isnot(None))
        .group_by(StockMove.order_id)
        .all()
    )
    stock_used = ZERO
    for order_id, amount in per_order_stock:
        amount = to_money(amount)
        order_expense[order_id] = order_expense.get(order_id, ZERO) + amount
        stock_used += amount

    orders = []
    if order_expense:
        orders = (
            Order.query.options(joinedload(Order.client), selectinload(Order.items))
            .filter(Order.id.in_(list(order_expense)), Order.is_deleted.is_(False))
            .all()
        )

    order_rows = []
    product_totals = {}
    for o in orders:
        spent = order_expense.get(o.id, ZERO)
        revenue = to_money(o.total_price)
        order_rows.append({
            "order": o, "spent": spent, "revenue": revenue, "profit": revenue - spent,
        })

        # Buyurtma xarajatini mahsulot turlari orasida ulushga qarab taqsimlaymiz:
        # 100 000 so'mlik buyurtmadagi 60 000 so'mlik vizitkaga xarajatning 60% i tegadi.
        items = o.items
        if not items:
            continue
        items_total = sum((to_money(i.total_price) for i in items), ZERO)
        for item in items:
            if items_total > ZERO:
                share = to_money(spent * to_money(item.total_price) / items_total)
            else:
                share = to_money(spent / len(items))
            row = product_totals.setdefault(
                item.order_type, {"spent": ZERO, "revenue": ZERO, "count": 0}
            )
            row["spent"] += share
            row["revenue"] += to_money(item.total_price)
            row["count"] += 1

    order_rows.sort(key=lambda r: r["spent"], reverse=True)

    product_rows = [
        {
            "name": name,
            "spent": values["spent"],
            "revenue": values["revenue"],
            "profit": values["revenue"] - values["spent"],
            "count": values["count"],
        }
        for name, values in product_totals.items()
    ]
    product_rows.sort(key=lambda r: r["spent"], reverse=True)

    return {
        "category_rows": category_rows,
        "linked": linked,
        "general": general,
        "stock_used": stock_used,
        "order_rows": order_rows,
        "product_rows": product_rows,
    }


def date_range_for_year(year):
    from datetime import date
    return date(year, 1, 1), date(year + 1, 1, 1)


# ---------- tahlil ----------

@finance_bp.route("/tahlil")
@login_required
@permission_required("reports.view")
def analytics():
    year = request.args.get("year", today_local().year, type=int)
    start, end = date_range_for_year(year)

    # eng ko'p tushum keltirgan mijozlar
    top_clients = (
        db.session.query(Client.id, Client.name, func.coalesce(func.sum(Payment.amount), 0).label("total"))
        .join(Order, Order.client_id == Client.id)
        .join(Payment, Payment.order_id == Order.id)
        .filter(Payment.paid_on >= start, Payment.paid_on < end,
                Order.status != STATUS_CANCELLED, Order.is_deleted.is_(False))
        .group_by(Client.id, Client.name)
        .order_by(func.sum(Payment.amount).desc())
        .limit(10)
        .all()
    )

    # mahsulot turlari bo'yicha — buyurtma qatorlari kesimida hisoblanadi,
    # shuning uchun bir buyurtmadagi har bir mahsulot alohida ko'rinadi
    top_types = (
        db.session.query(
            OrderItem.order_type,
            func.count(OrderItem.id).label("cnt"),
            func.coalesce(func.sum(OrderItem.total_price), 0).label("total"),
        )
        .join(Order, OrderItem.order_id == Order.id)
        .filter(Order.created_at >= start, Order.created_at < end,
                Order.status != STATUS_CANCELLED, Order.is_deleted.is_(False))
        .group_by(OrderItem.order_type)
        .order_by(func.sum(OrderItem.total_price).desc())
        .limit(10)
        .all()
    )

    total_orders = Order.query.filter(
        Order.created_at >= start, Order.created_at < end, Order.is_deleted.is_(False)
    ).count()
    cancelled = Order.query.filter(
        Order.created_at >= start, Order.created_at < end,
        Order.status == STATUS_CANCELLED, Order.is_deleted.is_(False)
    ).count()
    countable = total_orders - cancelled

    revenue_sum = to_money(
        db.session.query(func.coalesce(func.sum(Order.total_price), 0))
        .filter(Order.created_at >= start, Order.created_at < end,
                Order.status != STATUS_CANCELLED, Order.is_deleted.is_(False))
        .scalar()
    )
    avg_order = to_money(revenue_sum / countable) if countable else ZERO
    cancel_rate = round(cancelled * 100 / total_orders, 1) if total_orders else 0

    # qarzdor mijozlar — bitta agregat so'rov (avval 5201 ta edi)
    debtors = top_debtors(limit=10)

    return render_template(
        "finance/analytics.html",
        year=year,
        top_clients=[{"name": n, "total": to_money(t)} for _, n, t in top_clients],
        top_types=[{"name": t or "-", "count": c, "total": to_money(s)} for t, c, s in top_types],
        total_orders=total_orders, cancelled=cancelled, cancel_rate=cancel_rate,
        avg_order=avg_order, revenue_sum=revenue_sum,
        debtors=debtors,
    )


# ---------- Excel eksport ----------

@finance_bp.route("/hisobot/excel")
@login_required
@permission_required("reports.export")
def export_report():
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill

    year = request.args.get("year", today_local().year, type=int)
    months = year_rows(year)

    wb = Workbook()
    ws = wb.active
    ws.title = f"{year} moliyaviy hisobot"

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="2563EB")

    ws.append([f"{year}-yil moliyaviy hisoboti"])
    ws["A1"].font = Font(bold=True, size=14)
    ws.append([])

    headers = ["Oy", "Tushum", "Xarajat", "Foyda"]
    ws.append(headers)
    for col in range(1, len(headers) + 1):
        cell = ws.cell(row=3, column=col)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    for m in months:
        ws.append([m["name"], float(m["income"]), float(m["expense"]), float(m["profit"])])

    total_income = sum((m["income"] for m in months), ZERO)
    total_expense = sum((m["expense"] for m in months), ZERO)
    ws.append([])
    ws.append(["JAMI", float(total_income), float(total_expense), float(total_income - total_expense)])
    ws.cell(row=ws.max_row, column=1).font = Font(bold=True)

    for col, width in zip("ABCD", (18, 18, 18, 18)):
        ws.column_dimensions[col].width = width
    for row in ws.iter_rows(min_row=4, min_col=2, max_col=4):
        for cell in row:
            cell.number_format = "#,##0.00"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    log_action(current_user, "export", "report", None, f"{year} Excel")
    db.session.commit()
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=f"moliyaviy_hisobot_{year}.xlsx",
    )


@finance_bp.route("/xarajatlar/excel")
@login_required
@permission_required("reports.export")
def export_expenses():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    expenses = Expense.query.order_by(Expense.date.desc()).all()

    wb = Workbook()
    ws = wb.active
    ws.title = "Xarajatlar"
    ws.append(["Sana", "Turkum", "Summa", "Izoh", "Kiritgan"])
    for col in range(1, 6):
        cell = ws.cell(row=1, column=col)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="2563EB")

    for e in expenses:
        ws.append([
            e.date.strftime("%d.%m.%Y"),
            e.category,
            float(to_money(e.amount)),
            e.description or "",
            e.creator.display_name if e.creator else "",
        ])

    for col, width in zip("ABCDE", (14, 16, 16, 40, 20)):
        ws.column_dimensions[col].width = width
    for row in ws.iter_rows(min_row=2, min_col=3, max_col=3):
        for cell in row:
            cell.number_format = "#,##0.00"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="xarajatlar.xlsx",
    )


@finance_bp.route("/buyurtmalar/excel")
@login_required
@permission_required("reports.export")
def export_orders():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    # sana oralig'i bo'yicha cheklash (katta bazada xotirani himoya qiladi)
    try:
        date_from = parse_date(request.args.get("from"), "Boshlanish", required=False)
        date_to = parse_date(request.args.get("to"), "Tugash", required=False)
    except ValidationError as e:
        flash(str(e), "danger")
        return redirect(url_for("orders.list_orders"))

    q = Order.query.filter(Order.is_deleted.is_(False))
    if date_from:
        q = q.filter(Order.created_at >= date_from)
    if date_to:
        q = q.filter(Order.created_at < date_to)

    orders = eager_orders(q.order_by(Order.created_at.desc()).limit(20000)).all()

    wb = Workbook()
    ws = wb.active
    ws.title = "Buyurtmalar"
    ws.append(["№", "Sana", "Mijoz", "Turi", "Miqdor", "Summa", "To'langan", "Qolgan", "Holat", "Muddat"])
    for col in range(1, 11):
        cell = ws.cell(row=1, column=col)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="2563EB")

    for o in orders:
        ws.append([
            o.order_number,
            o.created_at.strftime("%d.%m.%Y") if o.created_at else "",
            o.client.name if o.client else "",
            o.order_type or "",
            o.quantity,
            float(to_money(o.total_price)),
            float(o.paid_amount_calc),
            float(o.remaining),
            o.status,
            o.deadline.strftime("%d.%m.%Y") if o.deadline else "",
        ])

    for col, width in zip("ABCDEFGHIJ", (14, 12, 26, 18, 10, 16, 16, 16, 14, 12)):
        ws.column_dimensions[col].width = width
    for row in ws.iter_rows(min_row=2, min_col=6, max_col=8):
        for cell in row:
            cell.number_format = "#,##0.00"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="buyurtmalar.xlsx",
    )
